var React = require('react-native');

var {
  Image,
  StyleSheet,
  Text,
  View,
  ListView,
  AlertIOS
} = React;

var REQUEST_URL = 'http://www.akshatpaul.com/list-properties';

var ListProperty = React.createClass({
  
  getInitialState: function() {
    var ds = new ListView.DataSource({rowHasChanged: (r1, r2) => r1 !== r2});
  	return {
    dataSource: new ListView.DataSource({
        rowHasChanged: (row1, row2) => row1 !== row2,
      }),
    loaded: false
  };
  },
  
  componentDidMount: function() {
    this.fetchData();
  },
   fetchData: function() {
    fetch(REQUEST_URL)
     .then((response) => response.json())
      .then((responseData) => {
        console.log(responseData);
        this.setState({
          house: responseData,
          dataSource: this.state.dataSource.cloneWithRows(responseData),
          loaded: true 
        });
      })
      .catch((error) => {
      AlertIOS.alert('No Donut for you');
      loaded: true 
   })
      .done();
  },


  render: function() {
     if (!this.state.loaded) {
      return this.renderLoadingView();
    }
    return (
      <ListView
        dataSource={this.state.dataSource}
        renderRow={this.renderProperty}
        style={styles.listView}/>
    );
  },

  renderProperty: function(property) {
    return (
      <View style={styles.container}>
        <Image
          source={{uri: property.images.thumbnail}}
          style={styles.thumbnail}/>
        <View style={styles.rightContainer}>
          <Text style={styles.name}>{property.name}</Text>
          <Text style={styles.address}>{property.address}</Text>
        </View>
      </View>
    );
  },
   renderLoadingView: function() {
    return (
      <View style={styles.container}>
        <Text>
          Loading houses...
        </Text>
      </View>
    );
  },

});

var styles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F5FCFF',
  },
  thumbnail: {
    width: 63,
    height: 91,
  },
  rightContainer: {
    flex: 1,
  },
  name: {
    fontSize: 20,
    marginBottom: 8,
    textAlign: 'center',
  },
  address: {
    textAlign: 'center',
  },
  listView: {
    paddingTop: 70,
    backgroundColor: '#F5FCFF',
  },
});



module.exports = ListProperty;