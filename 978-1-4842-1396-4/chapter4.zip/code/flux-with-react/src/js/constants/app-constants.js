module.exports = {
  ADD_ELEMENT: 'ADD_ELEMENT'
};
