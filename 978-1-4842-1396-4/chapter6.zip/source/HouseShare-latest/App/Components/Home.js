
var React = require('react-native');
var ListProperty = require('./ListProperty');
var REQUEST_URL = 'http://www.mocky.io/v2/563462d32600005e3023a21c';
var AddProperty = require('./AddProperty');
var {
  StyleSheet,
  Text,
  View,
  NavigatorIOS,
  TouchableHighlight,
  Image
} = React;


var Home = React.createClass({
   _handleListProperty: function() {
    this.props.navigator.push({
      title: "List of Properties",
      component: ListProperty
    })

  },

   _handleAddProperty: function() {
    this.props.navigator.push({
      title: "Add a Properties",
      component: AddProperty
    })
  },


  render: function() {
    return (
      <View style={styles.container}>
      <View style={styles.topBox} />
      <View style={styles.bottomBox} >
      </View>
      
      <View style={styles.topBox} >
      <TouchableHighlight 
      style={styles.button}
      onPress= {this._handleListProperty}
      underlayColor='#99d9f4'
      >
        <Text style={styles.buttonText}>List of properties</Text>
     </TouchableHighlight>
     <TouchableHighlight style={styles.button}
      onPress= {this._handleAddProperty}
       underlayColor='#99d9f4'>
        <Text style={styles.buttonText}>Add House</Text>
    </TouchableHighlight>
    </View>
   </View>
    );
  }
});


var styles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: 'column'
  },
  welcome: {
    fontSize: 25,
    textAlign: 'center'
  },
  navigator: {
    flex: 1
  },
   topBox: {
        flex: 1,
        backgroundColor: '#CCE5FF',
    },
    bottomBox: {
        flex: 1,
        backgroundColor: '#FFFFCC',
         alignItems: 'center',
         justifyContent: 'center'
    },
  button: {

  flex: 1,
  backgroundColor: '#48BBEC',
  borderColor: '#48BBEC',
  borderWidth: 1,
  borderRadius: 8,
  alignSelf: 'stretch',
  justifyContent: 'center',
  margin: 10
},
buttonText: {
  fontSize: 18,
  color: 'white',
  alignSelf: 'center'
}
});

module.exports = Home;