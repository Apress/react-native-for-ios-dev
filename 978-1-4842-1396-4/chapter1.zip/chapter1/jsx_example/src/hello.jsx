var Appo = React.createClass({
   render:function(){
    return React.DOM.h1(null, "Hello Past") 
   }
  });

  React.render(Appo(), document.body);