/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 */
'use strict';

var React = require('react-native');
var {
  AppRegistry,
  StyleSheet,
  Text,
  View,
  Animated
} = React;

var AnimationExample = React.createClass({
  getInitialState: function() {
    return {
      bounceValue: new Animated.Value(0),
      fadeAnim: new Animated.Value(0)
    };
  },
   componentDidMount() {
    this.state.bounceValue.setValue(1.5);     
    Animated.spring(                         
      this.state.bounceValue,                 
      {
        toValue: 0.8,                         
        friction: 1,                          
      }
    ).start(); 
    Animated.timing(       
          this.state.fadeAnim, 
          {
            toValue: 1,        
            duration: 2000,    
          },
        ).start();                                 
  },
  render: function() {
    return (
       <View style={styles.container}>
        <Animated.View
        style={{
          backgroundColor: '#DC143C',
          flex: 1,
            transform: [                        
            {scale: this.state.bounceValue},  
          ]
        }} />
        <Animated.View
        style={{
          backgroundColor: '#1E90FF',
          flex: 1,
          opacity: this.state.fadeAnim,
        
        }} />
      </View>       

    );
  }
});

var styles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: 'column'
  },
});

AppRegistry.registerComponent('AnimationExample', () => AnimationExample);
